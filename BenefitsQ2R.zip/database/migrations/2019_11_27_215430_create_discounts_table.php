<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDiscountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('discounts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('benefit');
            $table->string('name');
            $table->string('surname');
            $table->enum('gender', ['MASCULINO', 'FEMENINO', 'OTRO']);
            $table->string('whatsapp');
            $table->integer('amount_of_people');
            $table->enum('sent', ['SI', 'NO'])->default('NO');
            $table->enum('confirmation', ['SI', 'NO'])->default('NO');
            $table->string('type');
            $table->integer('creator');
            $table->integer('scanned_amount')->default(0);
            $table->integer('max_scanned_amount')->default(1);
            $table->enum('status', ['ACTIVA', 'CANCELADA', 'ENVIADA', 'CONFIRMADA', 'INGRESADA'])->default('ACTIVA');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('discounts');
    }
}
