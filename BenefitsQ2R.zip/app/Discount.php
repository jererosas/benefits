<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Discount extends Model
{
    
    use SoftDeletes;
    protected $table = "discounts";
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'benefit', 'name', 'surname', 'whatsapp', 'amount_of_people', 'sent', 'confirmation', 'gender', 'type', 'creator', 'max_scanned_amount', 'scanned_amount', 'status'
    ];
}
