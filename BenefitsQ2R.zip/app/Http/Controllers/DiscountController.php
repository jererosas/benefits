<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Discount;
use App\Benefit;
use DateTime;

class DiscountController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'adminorcreator'], ['except' => ['qr', 'confirm']]);
    }

    public function create(Request $request)
    {
        $request->validate(
            [
                'benefit' => ['required', 'integer', 'exists:benefits,id'],
                'name' => ['required', 'string'],
                'surname' => ['required', 'string'],
                'whatsapp' => ['required', 'string'],
                'amount_of_people' => ['required', 'integer', 'min:1'],
                'type' => ['required', 'string'],
                'gender' => ['required', 'string', 'in:MASCULINO,FEMENINO,OTRO']
            ],
            [
                'required' => 'El campo es requerido.',
                'string' => 'El campo debe de ser un texto válido.',
                'integer' => 'El campo debe de ser un número entero.'
            ]
        );


        Discount::create([
            'benefit' => $request->input('benefit'),
            'name' => $request->input('name'),
            'surname' => $request->input('surname'),
            'whatsapp' => $request->input('whatsapp'),
            'amount_of_people' => $request->input('amount_of_people'),
            'type' => $request->input('type'),
            'creator' => auth()->user()->id,
            'gender' => $request->input('gender'),
        ]);

        return redirect()->route('benefit_view', $request->input('benefit'))->with('success', 'Has creado correctamente la entrada para: ' . $request->input('name') . '.');
    }

    public function desactivate(Request $request)
    {
        $request->validate(
            [
                'discount' => ['required', 'integer', 'exists:discounts,id'],
            ],
            [
                'required' => 'El campo es requerido.',
                'exists' => 'La Entrada desactivar, debe de existir.',
                'integer' => 'El campo debe de ser un número entero.'
            ]
        );


        $discount = Discount::withoutTrashed()->where("id", $request->input("discount"))->first();

        if ($discount->status != "ACTIVA") {
            return redirect()->route('benefit_view', $discount->benefit)->with('error', 'Solo puedes desactivar una entrada si este se encuentra ACTIVA.');
        }

        $discount->status = "CANCELADA";
        $discount->save();

        return redirect()->route('benefit_view', $discount->benefit)->with('success', 'Has cancelado correctamente la entrada para: ' . $discount->name . ' ' . $discount->surname . '.');
    }

    public function activate(Request $request)
    {
        $request->validate(
            [
                'discount' => ['required', 'integer', 'exists:discounts,id'],
            ],
            [
                'required' => 'El campo es requerido.',
                'exists' => 'La Entrada a activar, debe de existir.',
                'integer' => 'El campo debe de ser un número entero.'
            ]
        );


        $discount = Discount::withoutTrashed()->where("id", $request->input("discount"))->first();

        if ($discount->status != "CANCELADA") {
            return redirect()->route('benefit_view', $discount->benefit)->with('error', 'Solo puedes activar la entrada si esta se encuentra CANCELADA.');
        }

        $discount->status = "ACTIVA";
        $discount->save();

        return redirect()->route('benefit_view', $discount->benefit)->with('success', 'Has activado correctamente la entrada para: ' . $discount->name . ' ' . $discount->surname . '.');
    }

    public function forceDelete(Request $request)
    {
        $request->validate(
            [
                'discount' => ['required', 'integer', 'exists:discounts,id'],
            ],
            [
                'required' => 'El campo es requerido.',
                'exists' => 'La entrada a eliminar, debe de existir.',
                'integer' => 'El campo debe de ser un número entero.'
            ]
        );


        $discount = Discount::withoutTrashed()->where("id", $request->input("discount"))->first();

        if ($discount->status == "CONFIRMADA" || $discount->status == "INGRESADA") {
            return redirect()->route('benefit_view', $discount->event)->with('error', 'Solo puedes eliminar una entrada si no se encuentra CONFIRMADA o INGRESADA.');
        }

        $discount->forceDelete();

        return redirect()->route('benefit_view', $discount->event)->with('success', 'Has eliminado correctamente la entrada para: ' . $discount->name . ' ' . $discount->surname . '.');
    }

    public function sent(Request $request)
    {
        $request->validate(
            [
                'discount' => ['required', 'integer', 'exists:discounts,id'],
            ],
            [
                'required' => 'El campo es requerido.',
                'exists' => 'La entrada a eliminar, debe de existir.',
                'integer' => 'El campo debe de ser un número entero.'
            ]
        );

        $discount = Discount::withoutTrashed()->where("id", $request->input("discount"))->first();

        $discount->sent = "SI";
        if ($discount->status == "ACTIVA") {
            $discount->status = "ENVIADA";
        }
        $discount->save();

        return response()->json([
            'status' => 'success',
            'code' => '200',
        ], 200);
    }

    public function confirm($benefit, $discount)
    {
        $bt = Benefit::withoutTrashed()->where("id", $benefit)->first();

        if (!$bt) {
            return view('confirm')->with('error', 'La entrada ya no existe.');
        }

        if (new DateTime() < new DateTime($bt->start_date)) {
            return view('qr')->with('error', 'Esta entrada empieza a ser válido en la fecha: ' . $bt->start_date);
        }
        if (new DateTime() > new DateTime($bt->end_date)) {
            return view('qr')->with('error', 'Esta entrada fue válido hasta la fecha: ' . $bt->end_date);
        }

        $dt = Discount::withoutTrashed()->where([["benefit", $benefit], ["id", $discount]])->first();

        if (!$dt) {
            return view('confirm')->with('error', 'La entrada es inválida.');
        }

        if ($dt->status == "CANCELADA") {
            return view('confirm')->with(['error' => 'Esta entrada fue cancelada.', 'discount' => $dt]);
        }

        /* if ($dt->status == "INGRESADA") {
            return view('confirm')->with(['error' => 'Este descuento ya fue utilizado.', 'discount' => $dt]);
        } */

        if ($dt->scanned_amount >= $dt->max_scanned_amount) {
            return view('confirm')->with(['error' => 'Esta entrada ya fue UTILIZADA el número máximo de veces (' . $dt->max_scanned_amount . ').', 'discount' => $dt]);
        }

        $dt->status = "INGRESADA";
        $dt->confirmation = "SI";
        $dt->scanned_amount = $dt->scanned_amount + 1;
        $dt->save();

        return view('confirm')->with(['success' => 'Entrada utilizada correctamente.', 'discount' => $dt]);
    }

    public function qr($benefit, $discount)
    {
        $bt = Benefit::withoutTrashed()->where("id", $benefit)->first();

        if (!$bt) {
            return view('qr')->with('error', 'La entrada ya no existe.');
        }

        if (new DateTime() < new DateTime($bt->start_date)) {
            return view('qr')->with('error', 'La entrada empieza a ser válido en la fecha: ' . $bt->start_date);
        }
        if (new DateTime() > new DateTime($bt->end_date)) {
            return view('qr')->with('error', 'La entrada fue válido hasta la fecha: ' . $bt->end_date);
        }

        $dt = Discount::withoutTrashed()->where([["benefit", $benefit], ["id", $discount]])->first();

        if (!$dt) {
            return view('qr')->with('error', 'La entrada es inválida.');
        }

        if ($dt->status == "CANCELADA") {
            return view('qr')->with(['error' => 'Esta entrada fue cancelada.', 'discount' => $dt]);
        }

        /* if ($dt->status == "INGRESADA") {
            return view('qr')->with(['error' => 'Este descuento ya fue utilizado.', 'discount' => $dt]);
        } */

        $image = \QrCode::format('png')
            ->size(500)->errorCorrection('H')
            ->generate(route('confirm', ["benefit" => $benefit, "discount" => $discount]));
        return response($image)->header('Content-type', 'image/png');
    }
}
