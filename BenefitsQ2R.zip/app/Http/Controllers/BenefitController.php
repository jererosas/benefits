<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Benefit;
use App\Discount;

class BenefitController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'admin'], ['except' => ['view_benefit']]);
    }

    public function view()
    {
        return view('home.admin.create_benefit')->with(["user" => auth()->user()]);
    }

    public function create(Request $request) {
        $request->validate([
            'name' => ['required', 'string', 'unique:benefits,name'],
            'description' => ['required', 'string'],
            'start_date' => ['required', 'string'],
            'end_date' => ['required', 'string']
        ],
        [
            'name.required' => 'El nombre es requerido.',
            'name.unique' => 'El nombre ya esta en uso.',
            'description.required' => 'La descripción es requerida.',
            'start_date.required' => 'La fecha de inicio es requerida.',
            'end_date.required' => 'La fecha de finalizacion es requerida.'
        ]);
        

        Benefit::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'start_date' => $request->input('start_date'),
            'end_date' => $request->input('end_date'),
            'creator' => auth()->user()->id
        ]);

        return redirect()->route('benefits')->with('success', 'Has creado correctamente la entrada: ' . $request->input('name') . '.');
    }

    public function view_edit($id) {
        $benefit = Benefit::where("id", $id)->first();

        if (!$benefit) {
            return redirect()->route('home')->with('error', 'La entrada que intentas editar no existe.');
        }

        return view('home.admin.edit_benefit')->with(["user" => auth()->user(), "benefit" => Benefit::where("id", $id)->first()]);
    }

    public function edit(Request $request, $id) {
        $benefit = Benefit::where("id", $id)->first();

        if (!$benefit) {
            return redirect()->route('home')->with('error', 'La entrada que intentas editar no existe.');
        }

        $request->validate([
            'name' => ['required', 'string', 'unique:benefits,name,'.$benefit->id],
            'description' => ['required', 'string'],
            'start_date' => ['required', 'string'],
            'end_date' => ['required', 'string']
        ],
        [
            'name.required' => 'El nombre es requerido.',
            'name.unique' => 'El nombre ya esta en uso.',
            'description.required' => 'La descripción es requerida.',
            'start_date.required' => 'La fecha de inicio es requerida.',
            'end_date.required' => 'La fecha de finalizacion es requerida.'
        ]);
        

        $benefit->name = $request->input("name");
        $benefit->description = $request->input("description");
        $benefit->start_date = $request->input("start_date");
        $benefit->end_date = $request->input("end_date");
        $benefit->save();

        return redirect()->route('home')->with('success', 'Has editado correctamente la entrada: ' . $request->input('name') . '.');
    }

    public function view_delete() {
        return view('home.admin.delete_benefit')->with(["user" => auth()->user(), "benefits" => Benefit::all()]);
    }

    public function delete(Request $request) {
        $request->validate([
            'benefit' => ['required', 'integer', 'exists:benefits,id'],
        ],
        [
            'benefit.required' => 'La entrada es requerido.',
            'benefit.exists' => 'La entrada no existe.'
        ]);
        

        $benefit = Benefit::where("id", $request->input("benefit"))->first();

        foreach (Discount::where("benefit", $benefit->id) as $discount) {
            $discount->forceDelete();
        }

        $benefit->forceDelete();

        return redirect()->route('benefits')->with('success', 'Has eliminado correctamente la entrada: ' . $benefit->name . '.');
    }

    public function view_benefit($id) {
        $benefit = Benefit::withTrashed()->where("id", $id)->first();

        if (!$benefit) {
            return redirect()->route('benefits')->with('error', 'La entrada que quieres visualizar, no existe.');
        }

        $discounts = Discount::withTrashed()->where("benefit", $id)->get();

        return view('home.admin.view_benefit')->with(["user" => auth()->user(), "benefit" => $benefit, "discounts" => $discounts]);
    }

    public function view_stats($id) {
        $benefit = Benefit::withTrashed()->where("id", $id)->first();

        if (!$benefit) {
            return redirect()->route('benefits')->with('error', 'La entrada al que quieres ver las estadísticas, no existe.');
        }

        $discounts = Discount::withTrashed()->where("benefit", $id)->get();

        return view('home.admin.view_stats')->with(["user" => auth()->user(), "users" => User::all(), "benefit" => $benefit, "discounts" => $discounts]);
    }

    public function get_stats_users(Request $request) {
        $benefit = Benefit::withTrashed()->where("id", $request->input("benefit"))->first();

        if (!$benefit) {
            return response()->json([
                'status' => 'error',
                'code' => '200',
            ], 200);
        }

        $discounts = Discount::withTrashed()->where("benefit", $request->input("benefit"))->get();
        $users = [];
        $data = [];

        foreach ($discounts as $discount) {
            $creator = User::where("id", $discount->creator)->first();
            
            if ($creator) {
                $name = "#" . $creator->id . " " . $creator->name;
            } else {
                $name = "#X Usuario eliminado";
            }

            if (in_array($name, $users) == false) {
                array_push($users, $name);
                $p = array_keys($users, "#" . $creator->id . " " . $creator->name);
                array_push($data, 1);
            } else {
                $p = array_keys($users, "#" . $creator->id . " " . $creator->name);
                $data[$p[0]] = $data[$p[0]] + 1;
            }
        }

        return response()->json([
            'status' => 'success',
            'code' => '200',
            'users' => $users,
            'data' => $data
        ], 200);
    }
}
