<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\User;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function view()
    {
        return view('home.admin.user')->with(["user" => auth()->user(), "users" => User::all()]);
    }

    public function create(Request $request) {
        $request->validate([
            'name' => ['required', 'string'],
            'email' => ['required', 'string', 'unique:users,email'],
            'password' => ['required', 'string'],
            'role' => ['required', 'string', 'in:admin,scanner,creator']
        ],
        [
            'email.required' => 'El email es requerido.',
            'email.unique' => 'El email ya esta en uso.',
            'password.required' => 'La contraseña es requerida.',
        ]);
        

        User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => Hash::make($request->input('password')),
            'role' => $request->input('role')
        ]);

        return redirect()->route('users')->with('success', 'Has creado correctamente al usuario: ' . $request->input('name') . '.');
    }

    public function forceDelete(Request $request)
    {
        $request->validate(
            [
                'user' => ['required', 'integer', 'exists:users,id'],
            ],
            [
                'user.required' => 'El usuario a eliminar completamente, es requerido.',
                'user.exists' => 'El usuario a eliminar completamente, no existe.',
            ]
        );


        $user = User::where("id", $request->input('user'))->first();

        if (!$user) {
            return redirect()->route('users')->with('error', 'Ups! Algo salio mal. Intentelo de nuevo.');
        }

        $user->delete();

        return redirect()->route('users')->with('success', 'Has eliminado completamente al usuario: ' . $user->name . '.');
    }
}
