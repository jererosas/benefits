<?php

namespace App\Providers;

use Illuminate\Contracts\Events\Dispatcher;
use JeroenNoten\LaravelAdminLte\Events\BuildingMenu;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

use App\Benefit;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(Dispatcher $events)
    {
        Schema::defaultStringLength(64);

        $events->listen(BuildingMenu::class, function (BuildingMenu $event) {
            $benefits = [
                [
                    'text' => 'Crear',
                    'url' => 'home/benefits',
                    'icon' => 'fas fa-fw fa-plus',
                    'can' => 'admin'
                ],
                [
                    'text' => 'Eliminar',
                    'url' => 'home/benefits/delete',
                    'icon' => 'fas fa-fw fa-trash',
                    'can' => 'admin'
                ]
            ];
            
            foreach (Benefit::all() as $bt) {
                if ($bt->status == "ACTIVO") {
                    $icon_color = "green";
                } elseif ($bt->status == "CANCELADO") {
                    $icon_color = "red";
                } else {
                    $icon_color = "blue";
                }

                $array = [
                    'text' => $bt->name,
                    'icon_color' => $icon_color,
                    'submenu' => [
                        [
                            'text' => 'Ver',
                            'url' => 'home/benefit/' . $bt->id,
                            'icon_color' => 'blue',
                            'icon' => 'fas fa-fw fa-eye'
                        ],
                        [
                            'text' => 'Editar',
                            'url' => 'home/benefit/' . $bt->id . '/edit',
                            'icon_color' => 'orange',
                            'icon' => 'fas fa-fw fa-edit'
                        ],
                        [
                            'text' => 'Estadísticas',
                            'url' => 'home/benefit/' . $bt->id . '/stats',
                            'icon_color' => 'green',
                            'icon' => 'fas fa-fw fa-chart-bar',
                            'can' => 'admin'
                        ]
                    ]
                ];

                array_push($benefits, $array);
            }

            $event->menu->add([
                'text' => 'Eventos',
                'icon' => 'fab fa-fw fa-elementor',
                'submenu' => $benefits
            ]);
        });
    }
}
