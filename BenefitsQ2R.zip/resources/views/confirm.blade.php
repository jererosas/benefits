<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SISTEMA - GOSHOW EFFECT</title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/confirm.css') }}" rel="stylesheet">
</head>

<body>
    <div class="col-12 d-flex flex-column justify-content-center align-items-center" id="main">
        @if (isset($error))
        <div class="login-logo">
    <IMG src="../../../imgs/logo.png">
    </div>
        <div class="col-12 col-md-6 col-lg-4 d-flex flex-column rounded p-3" style="background: red; color: white;">
            {{$error}}
        </div>
        @endif
        @if (isset($success))
        <div class="login-logo">
    <IMG src="../../../imgs/logo.png">
    </div>
        <div class="col-12 col-md-6 col-lg-4 d-flex flex-column rounded p-3" style="background: green; color: white;">
            Entrada Aceptada
        </div>
        <div class="col-12 col-md-6 col-lg-4 d-flex flex-column rounded p-3" style="background: white;">
            <div class="col-12">Nombre: {{ $discount->name }}</div>
            <div class="col-12">Apellido: {{ $discount->surname }}</div>
            <div class="col-12">WahtsApp: {{ $discount->whatsapp }}</div>
            <div class="col-12">Género: {{ $discount->gender }}</div>
            <div class="col-12">Cantidad de personas: {{ $discount->amount_of_people }}</div>
            <div class="col-12">MESA N°: {{ $discount->type }}</div>
            <hr>
            <div class="col-12">Veces Escaneado: {{ $discount->scanned_amount }}</div>
        </div>
        @endif
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/jquery-3.4.1.min.js') }}"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script src="{{ asset('js/popper.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
</body>

</html>