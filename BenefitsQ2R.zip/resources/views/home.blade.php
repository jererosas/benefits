@extends('adminlte::page')

@section('content')
Bienvenido a tu panel de administración de entradas QR.
@stop