@extends('adminlte::page')

@section('title', 'SISTEMA - GOSHOW EFFECT | Panel | Editar Entrada')

@section('content_header')
<h1 class="pl-2">EDITAR ENTRADA: {{$benefit->name}}</h1>
@stop

@section('content')
<hr>

<div class="col-12 col-md-6 mx-auto p-4 mt-3 rounded" style="background: white;">
    <form action="{{ route('benefit_edit', $benefit->id) }}" method="POST" accept-charset="UTF-8">
        @csrf
        <div class="form-group">
            <label for="name" style="font-weight: 500;">Nombre</label>
            <input type="text" class="form-control" name="name" id="name" value="{{$benefit->name}}" required>
            @if ($errors->has('name'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('name') }}</strong>
            </span>
            @endif
        </div>
        <div class="form-group">
            <label for="description" style="font-weight: 500;">Descripción <small>(corta)</small></label>
            <input type="text" class="form-control" name="description" id="description" value="{{$benefit->description}}" required>
            @if ($errors->has('description'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('description') }}</strong>
            </span>
            @endif
        </div>
        <div class="form-group">
            <label for="start_date" style="font-weight: 500;">Fecha de comienzo</label>
            <div class="col-12 p-0">
                <input class="form-control" type="date" name="start_date" id="start_date" value="{{$benefit->start_date}}">
            </div>
            @if ($errors->has('start_date'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('start_date') }}</strong>
            </span>
            @endif
        </div>
        <div class="form-group">
            <label for="end_date" style="font-weight: 500;">Fecha de finalizacio</label>
            <div class="col-12 p-0">
                <input class="form-control" type="date" name="end_date" id="end_date" value="{{$benefit->end_date}}">
            </div>
            @if ($errors->has('end_date'))
            <span class="invalid-feedback" role="alert">
                <strong>{{ $errors->first('end_date') }}</strong>
            </span>
            @endif
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block">EDITAR</button>
        </div>
    </form>
</div>
@stop