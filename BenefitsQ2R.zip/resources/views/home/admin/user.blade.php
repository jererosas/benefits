@extends('adminlte::page')

@section('title', 'SISTEMA - GOSHOW EFFECT | Panel | Usuarios')

@section('content_header')
<h1 class="pl-2">ADMINISTRAR USUARIOS</h1>
@stop

@section('js')
<script type="text/javascript" defer>
    $(document).ready(function() {
        $('#table').DataTable({
            language: {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
            }
        });
    });
</script>
@stop

@section('content')
<div class="modal fade" id="generate" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Crear usuario</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('user_create') }}" method="POST" accept-charset="UTF-8">
                @csrf
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name" style="font-weight: 500;">Nombre</label>
                        <input type="text" class="form-control" name="name" id="name" required>
                        @if ($errors->has('name'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="email" style="font-weight: 500;">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                        @if ($errors->has('email'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="password" style="font-weight: 500;">Contraseña</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                        @if ($errors->has('password'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('password') }}</strong>
                        </span>
                        @endif
                    </div>
                    <hr>
                    <div class="form-group mt-2">
                        <label for="role" style="font-weight: 500;">Rol</label>
                        <select class="form-control select2" style="width: 100%;" tabindex="-1" aria-hidden="true" name="role" id="role" lang="es" required>
                            <option value="admin" @if(old('role')=='admin' ) selected @endif>ADMIN</option>
                            <option value="scanner" @if(old('role')=='scanner' ) selected @endif>ESCÁNER</option>
                            <option value="creator" @if(old('role')=='creator' ) selected @endif>CREADOR</option>
                        </select>
                        @if ($errors->has('role'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('role') }}</strong>
                        </span>
                        @endif
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
                    <button type="submit" class="btn btn-primary">CREAR</button>
                </div>
            </form>
        </div>
    </div>
</div>

<hr>

<div class="col-12 p-2 d-flex justify-content-center align-items-center">
    <button type="button" class="col-12 col-md-2 btn btn-primary" data-toggle="modal" data-target="#generate">CREAR USUARIO</button>
</div>

<hr>

<div class="col-12 p-2 mt-3">
    <table id="table" class="table table-striped table-bordered table-hover dt-responsive nowrap display">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Opciones</th>
            </tr>
        </tfoot>
        <tbody>
            @foreach ($users as $user)
            <tr>
                <td>{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                @if($user->role == "admin")
                <td>ADMIN</td>
                @elseif($user->role == "scanner")
                <td>ESCÁNER</td>
                @else
                <td>CREADOR</td>
                @endif
                <td>
                    <form action="{{ route('user_forcedelete') }}" method="POST">
                        @csrf
                        <input type="number" name="user" value="{{ $user->id }}" hidden>
                        <button class="btn btn-out btn-square" style="color: red" title="Forzar eliminado"><i class="fas fa-fw fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@stop