@extends('adminlte::page')

@section('title', 'SISTEMA - GOSHOW EFFECT | Panel | Entrada |' . $benefit->name)

@section('content_header')
<h1 class="pl-2">Entrada: <span style="text-transform: uppercase">{{ $benefit->name }}</span></h1>
@stop

@section('js')
<script type="text/javascript" defer>
    $(document).ready(function() {
        $(".select2").select2();
        $('#table').DataTable({
            language: {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
            }
        });

        $('.sent').on("click", function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: '/home/discount/sent',
                data: {
                    'discount': $(this).data("discount")
                },
                beforeSend: function() {},
                success: function(result) {
                    if (result.status == "success") {
                        location.reload();
                    }
                },
            });
        });
    });
</script>
@stop

@section('content')
@if($user->role == "admin" || $user->role == "creator")
<div class="modal fade" id="generate" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Crear entrada</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{ route('discount_create') }}" method="POST" accept-charset="UTF-8">
                @csrf
                <div class="modal-body">
                    <input type="text" value="{{$benefit->id}}" name="benefit" id="benefit" hidden required>
                    <div class="form-group">
                        <label for="name" style="font-weight: 500;">Nombre</label>
                        <input type="text" class="form-control" name="name" id="name" required>
                        @if ($errors->has('name'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="surname" style="font-weight: 500;">Apellido</label>
                        <input type="text" class="form-control" name="surname" id="surname" required>
                        @if ($errors->has('surname'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('surname') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group mt-2">
                        <label for="gender" style="font-weight: 500;">Género</label>
                        <select class="form-control select2" style="width: 100%;" tabindex="-1" aria-hidden="true" name="gender" id="gender" lang="es" required>
                            <option value="MASCULINO" @if(old('gender')=='MASCULINO' ) selected @endif>MASCULINO</option>
                            <option value="FEMENINO" @if(old('gender')=='FEMENINO' ) selected @endif>FEMENINO</option>
                            <option value="OTRO" @if(old('gender')=='OTRO' ) selected @endif>OTRO</option>
                        </select>
                        @if ($errors->has('gender'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('gender') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="whatsapp" style="font-weight: 500;">WhatsApp <small>(incluir código de país)</small></label>
                        <input type="text" class="form-control" name="whatsapp" id="whatsapp" value="+54" required>
                        @if ($errors->has('whatsapp'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('whatsapp') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="amount_of_people" style="font-weight: 500;">Cantidad de personas</label>
                        <input type="number" class="form-control" value="1" min="1" name="amount_of_people" id="amount_of_people" required>
                        @if ($errors->has('amount_of_people'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('amount_of_people') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="type" style="font-weight: 500;">Mesa <small>(ejemplo: 1)</small></label>
                        <input type="text" class="form-control" name="type" id="type" required>
                        @if ($errors->has('type'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('type') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="max_scanned_amount" style="font-weight: 500;">Máximo "veces escanear" <small>mínimo 1</small></label>
                        <input type="number" class="form-control" name="max_scanned_amount" min="1" id="max_scanned_amount" required>
                        @if ($errors->has('max_scanned_amount'))
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('max_scanned_amount') }}</strong>
                        </span>
                        @endif
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
                    <button type="submit" class="btn btn-primary">CREAR</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif

@if ($user->role == "admin" || $user->role == "creator")
<hr>

<div class="col-12 p-2 d-flex justify-content-center align-items-center">
    <button type="button" class="col-12 col-md-2 btn btn-primary" data-toggle="modal" data-target="#generate">CREAR ENTRADA</button>
</div>
@endif

<hr>

<div class="col-12 p-2 mt-3">
    <table id="table" class="table table-striped table-bordered table-hover dt-responsive nowrap display">
        <thead>
            <tr>
                @if ($user->role != "scanner")
                <th>Opciones</th>
                @endif
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Género</th>
                <th>WhatsApp</th>
                <th>Cantidad de personas</th>
                <th>Enviado</th>
                <th>Confirmado</th>
                <th>Estado</th>
                <th>Mesa</th>
                <th>Máximo "veces escaneado"</th>
                <th>Veces escaneado</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                @if ($user->role != "scanner")
                <th>Opciones</th>
                @endif
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Género</th>
                <th>WhatsApp</th>
                <th>Cantidad de personas</th>
                <th>Enviado</th>
                <th>Confirmado</th>
                <th>Estado</th>
                <th>Mesa</th>
                <th>Máximo "veces escaneado"</th>
                <th>Veces escaneado</th>
            </tr>
        </tfoot>
        <tbody>
            @foreach ($discounts as $discount)
            <tr>
            <td>
                    <ul class="list-inline">
                        @if ($user->role != "scanner")
                        <li class="list-inline-item">
                            <a href="https://api.whatsapp.com/send?phone={{$discount->whatsapp}}&text={{route('qr', ['benefit' => $discount->benefit, 'discount' => $discount->id])}}" target="_blank" class="btn btn-out btn-square sent" data-discount="{{$discount->id}}" style="color: #128c7e; font-size: 1.2rem;" title="Compartir por whatsapp"><i class="fab fa-fw fa-whatsapp-square"></i></a>
                        </li>
                        @endif
                        @if ($user->role != "scanner")
                        @php ($v = false)
                        @if ($user->role == "creator" && $user->id == $discount->creator)
                        @php($v = true)
                        @endif
                        @if ($v == true)
                        @if ($discount->status != "CONFIRMADA" && $discount->status != "INGRESADA")
                        <li class="list-inline-item">
                            <form action="{{ route('discount_forcedelete') }}" method="POST">
                                @csrf
                                <input type="number" name="discount" value="{{ $discount->id }}" hidden>
                                <button class="btn btn-out btn-square" style="color: red; font-size: 1.2rem;" title="Forzar eliminado"><i class="fas fa-fw fa-trash"></i></button>
                            </form>
                        </li>
                        @endif
                        @endif
                        @endif
                        @if ($user->role == "admin")
                        @if ($discount->status == "ACTIVA")
                        <li class="list-inline-item">
                            <form action="{{ route('discount_desactivate') }}" method="POST">
                                @csrf
                                <input type="number" name="discount" value="{{ $discount->id }}" hidden>
                                <button class="btn btn-out btn-square" style="color: orange; font-size: 1.2rem;" title="Desactivar"><i class="fas fa-fw fa-times"></i></button>
                            </form>
                        </li>
                        @elseif ($discount->status == "CANCELADA")
                        <li class="list-inline-item">
                            <form action="{{ route('discount_activate') }}" method="POST">
                                @csrf
                                <input type="number" name="discount" value="{{ $discount->id }}" hidden>
                                <button class="btn btn-out btn-square" style="color: green; font-size: 1.2rem;" title="Activar"><i class="fas fa-fw fa-plus"></i></button>
                            </form>
                        </li>
                        @endif
                        @endif
                    </ul>
                </td>
                <td>{{ $discount->name }}</td>
                <td>{{ $discount->surname }}</td>
                <td>{{ $discount->gender }}</td>
                <td>{{ $discount->whatsapp }}</td>
                <td>{{ $discount->amount_of_people }}</td>
                <td>{{ $discount->sent }}</td>
                <td>{{ $discount->confirmation }}</td>
                <td>{{ $discount->status }}</td>
                <td>{{ $discount->type }}</td>
                <td>{{ $discount->max_scanned_amount }}</td>
                <td>{{ $discount->scanned_amount }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@stop