@extends('adminlte::page')

@section('title', 'SISTEMA - GOSHOW EFFECT | Panel | Entradas | Estadísticas |' . $benefit->name)

@section('content_header')
<h1 class="pl-2">Estadísticas del sitema: <span style="text-transform: uppercase">{{ $benefit->name }}</span></h1>
@stop

@section('js')
@php($created = $discounts->count())
@php($sent = $discounts->where("sent", "SI")->count())
@php($confirmed = $discounts->where("confirmation", "SI")->count())
<script type="text/javascript" defer>
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: '/home/benefit/stats/get/users',
            data: {
                'benefit': {{$benefit->id}}
            },
            beforeSend: function() {},
            success: function(result) {
                if (result.status == "success") {
                    var ctx = document.getElementById('myChart').getContext('2d');
                    var myChart = new Chart(ctx, {
                        type: 'pie',
                        data: {
                            labels: result.users,
                            datasets: [{
                                label: '# Usuarios',
                                data: result.data,
                                backgroundColor: [
                                    'rgba(255, 206, 86, 0.2)',
                                    'rgba(54, 162, 235, 0.2)',
                                    'rgba(75, 192, 192, 0.2)'
                                ],
                                borderColor: [
                                    'rgba(255, 206, 86, 1)',
                                    'rgba(54, 162, 235, 1)',
                                    'rgba(75, 192, 192, 1)'
                                ],
                                borderWidth: 1
                            }]
                        }
                    });
                }
            },
        });


        var ctx2 = document.getElementById('myChart2').getContext('2d');     
        var created = {{$created}};
        var sent = {{$sent}};
        var confirmed = {{$confirmed}};
        var myChart2 = new Chart(ctx2, {
            type: 'pie',
            data: {
                labels: ['Creadas', 'Enviadas', 'Confirmadas'],
                datasets: [{
                    label: '# Estados',
                    data: [created, sent, confirmed],
                    backgroundColor: [
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(75, 192, 192, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 206, 86, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(75, 192, 192, 1)'
                    ],
                    borderWidth: 1
                }]
            }
        });
    });
</script>
@stop

@section('content')

<hr>

<div class="col-12 p-2 d-flex flex-column flex-lg-row justify-content-center justify-content-lg-around align-items-center">
    <div class="col-12 col-lg-5 text-center">
        <strong>Entradas creados por usuario</strong>
        <canvas id="myChart" width="400" height="400"></canvas>
    </div>
    <div class="col-12 col-lg-5 text-center">
        <strong>Estado de las Entradas</strong>
        <canvas id="myChart2" width="400" height="400"></canvas>
    </div>
</div>
@stop