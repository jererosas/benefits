@extends('adminlte::page')

@section('title', 'SISTEMA - GOSHOW EFFECT | Panel | Eliminar entrada')

@section('content_header')
<h1 class="pl-2">ELIMINAR ENTRADA</h1>
@stop

@section('content')
<hr>

<div class="col-12 col-md-6 mx-auto p-4 mt-3 rounded" style="background: white;">
	<form action="{{ route('benefit_delete') }}" method="POST" accept-charset="UTF-8">
		@csrf
		<div class="form-group mt-2">
			<label for="benefit" style="font-weight: 500;">Entrada a eliminar</label>
			<select class="form-control select2" style="width: 100%;" tabindex="-1" aria-hidden="true" name="benefit" id="benefit" lang="es" required>
				@foreach ($benefits as $benefit)
				<option value="{{$benefit->id}}" @if(old('benefit')==$benefit->id) selected @endif>{{$benefit->name}}</option>
				@endforeach
			</select>
			@if ($errors->has('benefit'))
			<span class="invalid-feedback" role="alert">
				<strong>{{ $errors->first('benefit') }}</strong>
			</span>
			@endif
		</div>
		<div class="form-group">
			<button type="submit" class="btn btn-danger btn-block">ELIMINAR</button>
		</div>
	</form>
</div>
@stop