@extends('adminlte::login')
<style>
    .body {
        background-image: linear-gradient(rgba(0, 0, 0, .6), rgba(0, 0, 0, .6)), url("./imgs/ODRADL0.jpg");
        background-position: center center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }

    .login-logo a {
        color: white;
    }
</style>