<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sistema de eventos</title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/qr.css') }}" rel="stylesheet">
</head>

<body>
    <div class="col-12 d-flex flex-column justify-content-center align-items-center" id="main">
        @if (isset($error))
        <div class="col-12 col-md-6 col-lg-4 d-flex flex-column rounded p-3" style="background: red; color: white;">
            {{$error}}
        </div>
        @endif
        @if (isset($success))
        <div class="col-12 col-md-6 col-lg-4 d-flex flex-column rounded p-3" style="background: green; color: white;">
            QR De acceso
        </div>
        <div class="col-12 col-md-6 col-lg-4 d-flex flex-column rounded p-3" style="background: white;">
            {!! QrCode::format('png')->size(250)->generate(route('qr', ["benefit" => $benefit->id, "discount" => $discount->id])) !!}
        </div>
        @endif
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/jquery-3.4.1.min.js') }}"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script src="{{ asset('js/popper.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
</body>

</html>