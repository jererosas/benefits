<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('home');
});

Auth::routes([
    'register' => false,
    'verify' => false
]);

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/home/users', 'UserController@view')->name('users');
Route::post('/home/user/create', 'UserController@create')->name('user_create');
Route::post('/home/user/forcedelete', 'UserController@forcedelete')->name('user_forcedelete');

Route::get('/home/benefits', 'BenefitController@view')->name('benefits');
Route::post('/home/benefit/create', 'BenefitController@create')->name('benefit_create');
Route::get('/home/benefits/delete', 'BenefitController@view_delete')->name('benefit_view_delete');
Route::post('/home/benefit/delete', 'BenefitController@delete')->name('benefit_delete');
Route::get('/home/benefit/{id}', 'BenefitController@view_benefit')->name('benefit_view');
Route::get('/home/benefit/{id}/stats', 'BenefitController@view_stats')->name('benefit_stats');
Route::get('/home/benefit/{id}/edit', 'BenefitController@view_edit')->name('benefit_view_edit');
Route::post('/home/benefit/{id}/edit', 'BenefitController@edit')->name('benefit_edit');
Route::post('/home/benefit/stats/get/users', 'BenefitController@get_stats_users');

Route::post('/home/discount/create', 'DiscountController@create')->name('discount_create');
Route::post('/home/discount/forcedelete', 'DiscountController@forcedelete')->name('discount_forcedelete');
Route::post('/home/discount/activate', 'DiscountController@activate')->name('discount_activate');
Route::post('/home/discount/desactivate', 'DiscountController@desactivate')->name('discount_desactivate');
Route::post('/home/discount/sent', 'DiscountController@sent')->name('discount_sent');

Route::get('/discount/{benefit}/{discount}/confirm', 'DiscountController@confirm')->name('confirm')->middleware(['auth', 'scanneroradmin']);
Route::get('/discount/{benefit}/{discount}/qr', 'DiscountController@qr')->name('qr');